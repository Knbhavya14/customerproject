package com.cts.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.springmvc.entity.Admin;
import com.cts.springmvc.entity.Customer;
//import com.cts.EmployeeBean;
import com.cts.springmvc.service.impl.ServiceLayer;

@Controller
public class ControllerLayer {

	@Autowired
	private ServiceLayer SerObj;
	

	@RequestMapping("callproj")
	
	public String Home()
	{	
		//employee attribute==modelattribute in register.jsp
		//m.addAttribute("employee",new Employee());
		return "Home";//register.jsp==form action=register
	}
	
	@RequestMapping("register")
	public String createUser1(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("customer",new Customer());
		return "register";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "register", method = RequestMethod.POST)
	public String createUser(@ModelAttribute Customer customer1,Model m)
	{
		SerObj.createCustomer(customer1);//save(employee)
		 return "redirect:/view"; //redirect to request pattern::view
	       }
	//selection
	@RequestMapping(value = "view", method = RequestMethod.GET)
	public String view(@ModelAttribute Customer customer1,Model m)
	{
		List<Customer> obj=SerObj.getcus();
		m.addAttribute("cus",obj);//emps can beaccessin ViewEmp.jsp
			return "ViewCus";//ViewEmp.jsp
	}
	//deletion
    @RequestMapping(value="/deletecus/{delno}",method = RequestMethod.GET)    
    public String delcus(
    		@PathVariable 
    		int delno)
    {    
        
		SerObj.deletecus(delno);
        return "redirect:/view"; //call req pattern /view
    } 
    

	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView viewLogin(@ModelAttribute Admin admin) {
		return new ModelAndView("login");//login.jsp
	}


	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView processLogin(@ModelAttribute Admin admin) 
	{
		boolean emp = SerObj.checkLogin(admin.getVusername(),admin.getVpassword());
		ModelAndView model = null;
		if (emp) 
		{
			model = new ModelAndView("loginsuccess");//loginsuccess.jsp
			model.addObject("emp", admin.getVusername());//access in jsp
			
		} else {
			model = new ModelAndView("login");//login.jsp
			model.addObject("result", "Invalid Username or Password!!");
		}
		return model;
	}

        

}
